package com.formation.gc.services;

import java.util.List;

import com.formation.gc.entities.Compte;
import com.formation.gc.model.MessageResponse;

public interface CompteService {
	public MessageResponse save(Compte compte) throws Exception;
	public MessageResponse update(Compte compte) throws Exception;
	public MessageResponse delete(Compte compte) throws Exception;
	public List<Compte> findAll() throws Exception;
}
