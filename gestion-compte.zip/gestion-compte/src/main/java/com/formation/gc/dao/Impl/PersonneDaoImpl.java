package com.formation.gc.dao.Impl;

import com.formation.gc.dao.PersonneDao;
import com.formation.gc.entities.Personne;

public class PersonneDaoImpl extends GenericDaoImpl<Personne, String> implements PersonneDao{
	

}
