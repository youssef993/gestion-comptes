package com.formation.gc.services.impl;

import java.util.List;

import com.formation.gc.dao.CompteDao;
import com.formation.gc.dao.Impl.CompteDaoImpl;
import com.formation.gc.entities.Compte;
import com.formation.gc.model.MessageResponse;
import com.formation.gc.services.CompteService;

public class CompteSeviceImpl implements CompteService {

	private CompteDao cmptDao = new CompteDaoImpl();
	@Override
	public MessageResponse save(Compte compte) throws Exception {
		// TODO Auto-generated method stub
		cmptDao.save(compte);
		return new MessageResponse(true,"op�ration effectu� avec succes");
	}

	@Override
	public MessageResponse update(Compte compte) throws Exception {
		// TODO Auto-generated method stub
		cmptDao.update(compte);
		return new MessageResponse(true,"op�ration effectu� avec succes");
	}

	@Override
	public MessageResponse delete(Compte compte) throws Exception {
		// TODO Auto-generated method stub
		cmptDao.delete(compte);
		return new MessageResponse(true,"op�ration effectu� avec succes");
	}

	@Override
	public List<Compte> findAll() throws Exception {
		// TODO Auto-generated method stub
		return cmptDao.findAll();
	}
	
	
}
