package com.formation.gc.dao;

import com.formation.gc.entities.Personne;

public interface PersonneDao extends GenericDao<Personne, String>{

}
