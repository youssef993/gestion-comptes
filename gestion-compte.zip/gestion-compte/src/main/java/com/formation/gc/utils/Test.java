package com.formation.gc.utils;

import com.formation.gc.dao.PersonneDao;
import com.formation.gc.dao.Impl.PersonneDaoImpl;
import com.formation.gc.entities.Personne;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Personne personne=new Personne("112566533", "5555555", "555555", "9525832", "5555258632");
		PersonneDao personneDao = new PersonneDaoImpl();
		try {
			personneDao.save(personne);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
