package com.formation.gc.dao;

import com.formation.gc.entities.Compte;

public interface CompteDao extends GenericDao<Compte, Integer> {

}
