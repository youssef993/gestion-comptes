package com.formation.gc.services.impl;

import java.util.List;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import com.formation.gc.dao.PersonneDao;
import com.formation.gc.dao.Impl.PersonneDaoImpl;
import com.formation.gc.entities.Personne;
import com.formation.gc.model.MessageResponse;
import com.formation.gc.services.PersonneService;

public class PersonneServiceImpl implements PersonneService {

	private PersonneDao persDao = new PersonneDaoImpl();

	@Override
	public MessageResponse save(Personne personne) throws Exception {
		// TODO Auto-generated method stub
		Personne pers = persDao.findById(personne.getCin());
		if (pers != null) {
			return new MessageResponse(false, "CIN existent");
		}
		Criterion crit = Restrictions.eq("email", personne.getEmail());
		List<Personne> list = persDao.findByCriteria(crit);
		if (!list.isEmpty()) {
			return new MessageResponse(false, "Email existent");
		}
		persDao.save(personne);
		return new MessageResponse(true, "op�ration effectu� avec success");
	}

	@Override
	public MessageResponse update(Personne personne) throws Exception {
		Criterion crit1 = Restrictions.idEq(personne.getCin());
		Criterion crit2 = Restrictions.eq("email", personne.getEmail());
		// TODO Auto-generated method stub
		Criterion crit = Restrictions.and(crit1, crit2);
		List<Personne> list = persDao.findByCriteria(crit);
		if (list.isEmpty()) {
			list = persDao.findByCriteria(crit2);
			if (!list.isEmpty()) {
				return new MessageResponse(false, "Email existent");
			}
		}
		persDao.update(personne);
		return new MessageResponse(true, "op�ration effectu� avec success");
	}

	@Override
	public MessageResponse delete(Personne personne) throws Exception {
		Criterion crit=Restrictions.isNotEmpty("comptes");
		// TODO Auto-generated method stub
		List<Personne> list = persDao.findByCriteria(crit);
		if(!list.isEmpty()) {
			return new MessageResponse(false, "Ce personne aura un ou plusieur comptes");
		}
		persDao.delete(personne);
		return new MessageResponse(true, "op�ration effectu� avec success");
	}

	@Override
	public List<Personne> findAll() throws Exception {
		// TODO Auto-generated method stub
		return persDao.findAll();
	}

	public PersonneDao getPersDao() {
		return persDao;
	}

	public void setPersDao(PersonneDao persDao) {
		this.persDao = persDao;
	}

}
