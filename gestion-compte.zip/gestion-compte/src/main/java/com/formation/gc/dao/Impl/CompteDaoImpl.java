package com.formation.gc.dao.Impl;

import com.formation.gc.dao.CompteDao;
import com.formation.gc.entities.Compte;

public class CompteDaoImpl extends GenericDaoImpl<Compte, Integer> implements CompteDao {

}
