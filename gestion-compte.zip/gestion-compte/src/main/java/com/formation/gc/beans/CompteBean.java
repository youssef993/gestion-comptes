package com.formation.gc.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import com.formation.gc.entities.Compte;
import com.formation.gc.model.MessageResponse;
import com.formation.gc.services.CompteService;
import com.formation.gc.services.impl.CompteSeviceImpl;

@ManagedBean
@ViewScoped
public class CompteBean implements Serializable {

	private CompteService compteService = new CompteSeviceImpl();
	private List<Compte> list = new ArrayList<>();
	private Compte compte = new Compte();
	private boolean btnAdd, btnEdit;

	
	public void clickAdd() {
		btnAdd = true;
		btnEdit = false;
		compte=new Compte();
	}
	public void clickEdit() {
		btnAdd = false;
		btnEdit = true;
	}

	public void modifier() {
		try {
			MessageResponse result = compteService.update(compte);
			if (result.isSuccess()) {
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_INFO, "INFO", result.getMessage()));

			} else {

				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_WARN, "Attention", result.getMessage()));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "ERROR", "Op�ration non effectuer"));
		}
	}

	public void ajouter() {
		try {
			MessageResponse result = compteService.save(compte);
			if (result.isSuccess()) {
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_INFO, "INFO", result.getMessage()));

			} else {

				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_WARN, "Attention", result.getMessage()));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "ERROR", "Op�ration non effectuer"));
		}
	}

	public void suprimer() {
		try {
			MessageResponse result = compteService.delete(compte);
			if (result.isSuccess()) {
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_INFO, "INFO", result.getMessage()));

			} else {

				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_WARN, "Attention", result.getMessage()));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "ERROR", "Op�ration non effectuer"));
		}
	}

	public List<Compte> getList() {
		try {
			list = compteService.findAll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public void setList(List<Compte> list) {
		this.list = list;
	}

	public Compte getCompte() {
		return compte;
	}

	public void setCompte(Compte compte) {
		this.compte = compte;
	}

	public boolean isBtnAdd() {
		return btnAdd;
	}

	public void setBtnAdd(boolean btnAdd) {
		this.btnAdd = btnAdd;
	}

	public boolean isBtnEdit() {
		return btnEdit;
	}

	public void setBtnEdit(boolean btnEdit) {
		this.btnEdit = btnEdit;
	}

}
