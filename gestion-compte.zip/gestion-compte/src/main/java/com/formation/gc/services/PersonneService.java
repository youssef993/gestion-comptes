package com.formation.gc.services;

import java.util.List;

import com.formation.gc.entities.Personne;
import com.formation.gc.model.MessageResponse;

public interface PersonneService {
	public MessageResponse save(Personne personne) throws Exception;
	public MessageResponse update(Personne personne) throws Exception;
	public MessageResponse delete(Personne personne) throws Exception;
	public List<Personne> findAll() throws Exception;

}
